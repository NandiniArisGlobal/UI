interface Student {
  fname: string;
  lname: string;
  roll_no: number;
  class?: number;
}
let stu1: Student = {
  fname: "Nandini",
  lname: "S",
  roll_no: 18,
  class: 8
};
console.log(stu1);

let stu2: Student = {
  fname: "Sandhya",
  lname: "S",
  roll_no: 27
};
console.log(stu2);
