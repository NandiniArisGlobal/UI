let sum = (a: number, b: number, c?: number) => {
  return `${a} ${b} ${c}`;
};
console.log(sum(1, 2));
